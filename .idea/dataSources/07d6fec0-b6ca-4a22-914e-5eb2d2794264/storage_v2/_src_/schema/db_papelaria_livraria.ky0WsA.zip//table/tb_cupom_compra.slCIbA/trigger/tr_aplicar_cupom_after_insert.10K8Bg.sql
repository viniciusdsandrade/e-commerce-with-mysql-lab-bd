create definer = root@localhost trigger tr_aplicar_cupom_after_insert
    after insert
    on tb_cupom_compra
    for each row
BEGIN
    DECLARE desconto_cupom DECIMAL(10, 2);

    -- Obter o desconto do cupom
    SELECT desconto INTO desconto_cupom FROM tb_cupom WHERE id = NEW.id_cupom;

    -- Atualizar o preço total da compra com o desconto do cupom
    UPDATE tb_compra
    SET preco_total = preco_total - desconto_cupom
    WHERE id = NEW.id_compra;
END;

