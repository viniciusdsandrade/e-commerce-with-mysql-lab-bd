create
    definer = root@localhost function fun_calcular_desconto_promocao(id_produto_param bigint unsigned) returns decimal(10, 2)
    reads sql data
BEGIN
    DECLARE desconto_promocao DECIMAL(10, 2);

    SELECT p.desconto
    INTO desconto_promocao
    FROM tb_promocao_produto pp
             JOIN tb_promocao p ON pp.id_promocao = p.id
    WHERE pp.id_produto = id_produto_param
      AND NOW() BETWEEN p.data_inicio AND p.data_fim
    LIMIT 1; -- Garante que apenas um desconto seja retornado

    RETURN IFNULL(desconto_promocao, 0);
END;

