create definer = root@localhost view vw_views as
select row_number() OVER (ORDER BY `information_schema`.`views`.`TABLE_NAME` ) AS `row_num`,
       `information_schema`.`views`.`TABLE_NAME`                               AS `object_name`,
       'VIEW'                                                                  AS `object_type`
from `information_schema`.`VIEWS`
where (`information_schema`.`views`.`TABLE_SCHEMA` = 'db_papelaria_livraria');

