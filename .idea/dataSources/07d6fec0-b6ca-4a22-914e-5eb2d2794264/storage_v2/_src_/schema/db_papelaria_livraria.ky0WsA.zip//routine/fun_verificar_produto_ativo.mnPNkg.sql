create
    definer = root@localhost function fun_verificar_produto_ativo(id_produto bigint unsigned) returns tinyint(1)
    deterministic
    reads sql data
BEGIN
    DECLARE is_ativo BOOLEAN;

    SELECT is_ativo INTO is_ativo FROM tb_produto WHERE id = id_produto;

    RETURN is_ativo;
END;

