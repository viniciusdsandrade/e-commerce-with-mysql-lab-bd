create definer = root@localhost view vw_functions as
select row_number() OVER (ORDER BY `information_schema`.`routines`.`ROUTINE_NAME` ) AS `row_num`,
       `information_schema`.`routines`.`ROUTINE_NAME`                               AS `object_name`,
       'FUNCTION'                                                                   AS `object_type`
from `information_schema`.`ROUTINES`
where ((`information_schema`.`routines`.`ROUTINE_TYPE` = 'FUNCTION') and
       (`information_schema`.`routines`.`ROUTINE_SCHEMA` = 'db_papelaria_livraria'));

