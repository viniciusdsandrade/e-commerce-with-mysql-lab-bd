create
    definer = root@localhost function fun_gerar_row_num() returns int reads sql data
BEGIN
    RETURN ROW_NUMBER() OVER (ORDER BY NULL); -- Numeração sequencial sem variáveis
END;

