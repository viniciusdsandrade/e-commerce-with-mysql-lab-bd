create
    definer = root@localhost function fun_desativar_produto(id_produto bigint unsigned) returns tinyint(1)
    deterministic
    modifies sql data
BEGIN
    -- Verificar se o produto existe e está ativo
    IF fun_verificar_produto_ativo(id_produto) THEN
        -- Atualizar o campo is_ativo para false
        UPDATE tb_produto SET is_ativo = FALSE WHERE id = id_produto;
        RETURN TRUE;
    ELSE
        -- Retornar false se o produto não existe ou já está inativo
        RETURN FALSE;
    END IF;
END;

