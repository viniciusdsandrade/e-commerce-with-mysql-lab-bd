create definer = root@localhost trigger tr_calcular_preco_unitario_before_insert
    before insert
    on tb_compra_produto
    for each row
BEGIN
    DECLARE estoque_atual INT;
    DECLARE preco_produto DECIMAL(10, 2);
    DECLARE produto_ativo BOOLEAN;
    DECLARE desconto_promocao DECIMAL(10, 2);

    -- Obter a quantidade em estoque e o status do produto
    SELECT quantidade, is_ativo
    INTO estoque_atual, produto_ativo
    FROM tb_estoque
             JOIN tb_produto ON tb_estoque.id_produto = tb_produto.id
    WHERE id_produto = NEW.id_produto;

    -- Verificar se o produto está ativo
    IF produto_ativo = TRUE THEN
        -- Obter o preço do produto
        SELECT preco INTO preco_produto FROM tb_produto WHERE id = NEW.id_produto;

        -- Calcular o desconto da promoção (se houver)
        SELECT p.desconto
        INTO desconto_promocao
        FROM tb_promocao_produto pp
                 JOIN tb_promocao p ON pp.id_promocao = p.id
        WHERE pp.id_produto = NEW.id_produto
          AND NOW() BETWEEN p.data_inicio AND p.data_fim
        LIMIT 1;
        -- Garante que apenas um desconto seja aplicado, caso haja mais de uma promoção

        -- Verificar se há estoque suficiente
        IF estoque_atual >= NEW.quantidade THEN
            -- Definir o preço unitário como o preço do produto com desconto da promoção (se houver)
            SET NEW.quantidade = preco_produto * (1 - IFNULL(desconto_promocao, 0) / 100);
        ELSE
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Estoque insuficiente para o produto.';
        END IF;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Não é possível comprar um produto inativo.';
    END IF;
END;

