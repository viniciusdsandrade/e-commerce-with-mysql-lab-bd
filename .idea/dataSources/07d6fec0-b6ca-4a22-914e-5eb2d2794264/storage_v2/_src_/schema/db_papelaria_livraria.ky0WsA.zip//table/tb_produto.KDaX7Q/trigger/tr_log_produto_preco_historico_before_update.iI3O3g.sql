create definer = root@localhost trigger tr_log_produto_preco_historico_before_update
    before update
    on tb_produto
    for each row
BEGIN
    -- Verificar se o produto está ativo usando a função
    IF fun_verificar_produto_ativo(OLD.id) THEN
        IF OLD.preco != NEW.preco THEN
            INSERT INTO log_produto_preco_historico (id_produto, preco_anterior, preco_novo)
            VALUES (OLD.id, OLD.preco, NEW.preco);
        END IF;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Não é possível atualizar o preço de um produto inativo.';
    END IF;
END;

