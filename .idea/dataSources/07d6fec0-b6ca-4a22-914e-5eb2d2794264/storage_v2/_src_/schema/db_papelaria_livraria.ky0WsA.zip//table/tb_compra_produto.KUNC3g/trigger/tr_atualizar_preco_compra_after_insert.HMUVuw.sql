create definer = root@localhost trigger tr_atualizar_preco_compra_after_insert
    after insert
    on tb_compra_produto
    for each row
BEGIN
    DECLARE produto_ativo BOOLEAN;

    -- Obter o status do produto antes da atualização do preço da compra
    SELECT is_ativo INTO produto_ativo FROM tb_produto WHERE id = NEW.id_produto;

    -- Verificar se o produto está ativo usando a variável
    IF produto_ativo = TRUE THEN
        -- Atualizar o preço total da compra na tabela tb_compra
        UPDATE tb_compra
        SET preco_total = preco_total + (NEW.quantidade * (SELECT preco FROM tb_produto WHERE id = NEW.id_produto))
        WHERE id = NEW.id_compra;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Não é possível atualizar o preço da compra com um produto inativo.';
    END IF;
END;

