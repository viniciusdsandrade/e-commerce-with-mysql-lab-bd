create definer = root@localhost view vw_stored_procedures as
select row_number() OVER (ORDER BY `information_schema`.`routines`.`SPECIFIC_NAME` ) AS `row_num`,
       `information_schema`.`routines`.`SPECIFIC_NAME`                               AS `object_name`,
       'PROCEDURE'                                                                   AS `object_type`
from `information_schema`.`ROUTINES`
where ((`information_schema`.`routines`.`ROUTINE_TYPE` = 'PROCEDURE') and
       (`information_schema`.`routines`.`ROUTINE_SCHEMA` = 'db_papelaria_livraria'));

