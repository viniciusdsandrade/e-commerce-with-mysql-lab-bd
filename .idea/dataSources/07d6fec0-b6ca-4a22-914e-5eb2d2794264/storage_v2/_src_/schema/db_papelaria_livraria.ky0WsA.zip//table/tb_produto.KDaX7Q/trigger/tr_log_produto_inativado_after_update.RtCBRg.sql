create definer = root@localhost trigger tr_log_produto_inativado_after_update
    after update
    on tb_produto
    for each row
BEGIN
    -- Verificar se o produto está ativo antes da atualização
    IF fun_verificar_produto_ativo(OLD.id) THEN
        -- Verificar se o campo is_ativo foi atualizado para false
        IF OLD.is_ativo = TRUE AND NEW.is_ativo = FALSE THEN
            -- Inserir o produto na tabela log_produto_inativos
            INSERT INTO log_produto_inativos (id_produto, nome, preco, data_inativacao)
            VALUES (OLD.id, OLD.nome, OLD.preco, NOW());
        END IF;

        -- Verificar se o campo is_ativo foi atualizado para true
        IF OLD.is_ativo = FALSE AND NEW.is_ativo = TRUE THEN
            -- Atualizar a data de reativação na tabela log_produto_inativos
            UPDATE log_produto_inativos
            SET data_reativacao = NOW()
            WHERE id_produto = OLD.id;
        END IF;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Não é possível atualizar um produto inativo.';
    END IF;
END;

