create definer = root@localhost trigger tr_atualizar_estoque_after_insert
    after insert
    on tb_compra_produto
    for each row
BEGIN
    DECLARE produto_ativo BOOLEAN;

    -- Obter o status do produto antes da atualização do estoque
    SELECT is_ativo INTO produto_ativo FROM tb_produto WHERE id = NEW.id_produto;

    -- Verificar se o produto está ativo usando a variável
    IF produto_ativo = TRUE THEN
        -- Atualizar o estoque na tabela tb_estoque
        UPDATE tb_estoque
        SET quantidade = quantidade - NEW.quantidade
        WHERE id_produto = NEW.id_produto;

        -- Verificar se a quantidade em estoque ficou negativa
        IF (SELECT quantidade FROM tb_estoque WHERE id_produto = NEW.id_produto) < 0 THEN
            -- Lançar um erro para cancelar a operação
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Estoque insuficiente para o produto.';
        END IF;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Não é possível atualizar o estoque de um produto inativo.';
    END IF;
END;

