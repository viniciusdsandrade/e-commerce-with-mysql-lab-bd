create definer = root@localhost view vw_todos_os_recursos as
select row_number() OVER (ORDER BY `recursos`.`object_type`,`recursos`.`object_name` ) AS `row_num`,
       `recursos`.`object_name`                                                        AS `object_name`,
       `recursos`.`object_type`                                                        AS `object_type`
from (select `db_papelaria_livraria`.`vw_stored_procedures`.`object_name` AS `object_name`,
             `db_papelaria_livraria`.`vw_stored_procedures`.`object_type` AS `object_type`
      from `db_papelaria_livraria`.`vw_stored_procedures`
      union all
      select `db_papelaria_livraria`.`vw_views`.`object_name` AS `object_name`,
             `db_papelaria_livraria`.`vw_views`.`object_type` AS `object_type`
      from `db_papelaria_livraria`.`vw_views`
      union all
      select `db_papelaria_livraria`.`vw_functions`.`object_name` AS `object_name`,
             `db_papelaria_livraria`.`vw_functions`.`object_type` AS `object_type`
      from `db_papelaria_livraria`.`vw_functions`
      union all
      select `db_papelaria_livraria`.`vw_triggers`.`object_name` AS `object_name`,
             `db_papelaria_livraria`.`vw_triggers`.`object_type` AS `object_type`
      from `db_papelaria_livraria`.`vw_triggers`) `recursos`;

