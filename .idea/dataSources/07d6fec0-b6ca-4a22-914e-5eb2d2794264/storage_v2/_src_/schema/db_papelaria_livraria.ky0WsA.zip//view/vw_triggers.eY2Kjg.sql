create definer = root@localhost view vw_triggers as
select row_number() OVER (ORDER BY `information_schema`.`triggers`.`TRIGGER_NAME` ) AS `row_num`,
       `information_schema`.`triggers`.`TRIGGER_NAME`                               AS `object_name`,
       'TRIGGER'                                                                    AS `object_type`
from `information_schema`.`TRIGGERS`
where (`information_schema`.`triggers`.`TRIGGER_SCHEMA` = 'db_papelaria_livraria');

