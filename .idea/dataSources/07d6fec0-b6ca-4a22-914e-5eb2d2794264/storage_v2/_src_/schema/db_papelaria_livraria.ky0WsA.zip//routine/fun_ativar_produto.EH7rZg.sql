create
    definer = root@localhost function fun_ativar_produto(id_produto bigint unsigned) returns tinyint(1)
    deterministic
    modifies sql data
BEGIN
    -- Verificar se o produto existe e está inativo
    IF NOT fun_verificar_produto_ativo(id_produto) THEN
        -- Atualizar o campo is_ativo para true
        UPDATE tb_produto SET is_ativo = TRUE WHERE id = id_produto;
        RETURN TRUE;
    ELSE
        -- Retornar false se o produto não existe ou já está ativo
        RETURN FALSE;
    END IF;
END;

