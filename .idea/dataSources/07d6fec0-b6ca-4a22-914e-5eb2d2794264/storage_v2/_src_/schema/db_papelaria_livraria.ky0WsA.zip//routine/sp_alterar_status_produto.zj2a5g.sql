create
    definer = root@localhost procedure sp_alterar_status_produto(IN id_produto bigint unsigned, IN acao varchar(10))
BEGIN
    DECLARE resultado BOOLEAN;

    -- Verificar se a ação é ativar
    IF acao = 'ativar' THEN
        -- Chamar a função para ativar o produto
        SET resultado = fun_ativar_produto(id_produto);

        -- Verificar o resultado
        IF resultado THEN
            SELECT CONCAT('Produto ', id_produto, ' foi ativado com sucesso.') AS mensagem;
        ELSE
            SELECT CONCAT('Produto ', id_produto, ' já está ativo ou não foi encontrado.') AS mensagem;
        END IF;

        -- Verificar se a ação é desativar
    ELSEIF acao = 'desativar' THEN
        -- Chamar a função para desativar o produto
        SET resultado = fun_desativar_produto(id_produto);

        -- Verificar o resultado
        IF resultado THEN
            SELECT CONCAT('Produto ', id_produto, ' foi desativado com sucesso.') AS mensagem;
        ELSE
            SELECT CONCAT('Produto ', id_produto, ' já está inativo ou não foi encontrado.') AS mensagem;
        END IF;

    ELSE
        -- Se a ação não for nem 'ativar', nem 'desativar'
        SELECT 'Ação inválida. Utilize ''ativar'' ou ''desativar''.' AS mensagem;
    END IF;
END;

